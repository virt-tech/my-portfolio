function greetUser() {
    const hour = new Date().getHours();
    let greeting;

    if (hour < 12) {
        greeting = "Good Morning";
    } else if (hour < 18) {
        greeting = "Good Afternoon";
    } else {
        greeting = "Good Evening";
    }

    alert(`${greeting}! Welcome to Virtu_Tech's Website.`);
    showSection('home');
}

function showSection(id) {
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(id).style.display = 'block';
}

function validateContactForm() {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const message = document.getElementById('message').value.trim();

    if (!name || !email || !phone || !message) {
        alert('Please fill in all fields.');
        return false;
    }

    alert('Thank you for contacting us!');
    return true;
}

function toggleTheme() {
    document.body.classList.toggle('dark-theme');
}

// Search functionality
const searchableItems = [
    { title: 'Home', icon: 'fas fa-home', link: '#', section: 'home' },
    { title: 'About Us', icon: 'fas fa-info-circle', link: '#', section: 'about' },
    { title: 'Portfolio', icon: 'fas fa-briefcase', link: '#', section: 'portfolio' },
    { title: 'Contact', icon: 'fas fa-envelope', link: 'Contact.html', section: null },
    { title: 'Survey Page', icon: 'fas fa-poll', link: 'SurveyPage.html', section: null },
    { title: 'Location', icon: 'fas fa-map-marker-alt', link: 'https://maps.google.com/?q=Iyumbu,+Dodoma,+Tanzania', section: null },
    { title: 'Phone Numbers', icon: 'fas fa-phone', link: 'Contact.html', section: null },
    { title: 'Email', icon: 'fas fa-envelope', link: 'Contact.html', section: null },
    { title: 'Social Media', icon: 'fas fa-hashtag', link: 'Contact.html', section: null }
];

function toggleSearch(event) {
    event.preventDefault();
    const searchBox = document.getElementById('searchBox');
    searchBox.classList.toggle('active');
    if (searchBox.classList.contains('active')) {
        document.getElementById('searchInput').focus();
    }

    // Close search box when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.search-container')) {
            searchBox.classList.remove('active');
        }
    });
}

function searchPages() {
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    const query = searchInput.value.toLowerCase();

    // Clear previous results
    searchResults.innerHTML = '';

    if (query.length === 0) {
        return;
    }

    // Filter and display results
    const results = searchableItems.filter(item => 
        item.title.toLowerCase().includes(query)
    );

    results.forEach(result => {
        const resultItem = document.createElement('div');
        resultItem.className = 'search-result-item';
        resultItem.innerHTML = `
            <i class="${result.icon}"></i>
            <span>${result.title}</span>
        `;

        resultItem.addEventListener('click', () => {
            if (result.section) {
                showSection(result.section);
                document.getElementById('searchBox').classList.remove('active');
            } else {
                window.location.href = result.link;
            }
        });

        searchResults.appendChild(resultItem);
    });
}
