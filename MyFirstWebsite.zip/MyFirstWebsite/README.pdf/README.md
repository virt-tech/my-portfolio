// =======================================
// README – Personal Portfolio Project
// =======================================

// 🔧 Tools Used:
// - HTML5: For structuring the content of the website.
// - CSS3: For layout, design, and responsiveness.
// - JavaScript: For interactivity (e.g., welcome pop-up).
// - VS Code: Used as the main text editor.
// - Google Photos: Used to share design projects.

//  Key Features Implemented:
// - Navigation bar with working links (opens portfolio in new tab).
// - "My Portfolio" nav item linked to:
//   https://photos.app.goo.gl/X6SQQEa68eM4rPzv6
// - JavaScript pop-up greeting on first visit (e.g., "Good Evening!").
// - Clean, responsive one-page layout.
// - External links open in new tabs using target="_blank".

//  Challenges Faced & How They Were Solved:
// - Challenge: Spent a lot of time and energy restarting the project.
//   Solution: Took it one step at a time—first HTML, then CSS, and finally JS.
// - Challenge: Embedding Google Photos album did not work due to permission errors.
//   Solution: Switched to opening the album in a new browser tab for easy access.

//  Summary:
// This project reflects my dedication and effort to build a functional,
// visually clean, and accessible portfolio. It shows my basic understanding
// of front-end technologies and ability to learn and solve problems independently.

// =======================================
